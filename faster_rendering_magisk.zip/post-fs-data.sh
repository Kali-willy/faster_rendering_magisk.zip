#!/system/bin/sh
# Faster Rendering Module - Post-FS-Data Script
# Author: willygailo01@gmail.com

MODDIR=${0%/*}

# Create necessary directories
mkdir -p $MODDIR/system/bin
mkdir -p $MODDIR/system/etc

# Apply early boot optimizations
# These settings are applied earlier in the boot process

# Increase VM parameters for better performance
echo "128" > /proc/sys/vm/swappiness
echo "100" > /proc/sys/vm/vfs_cache_pressure
echo "20" > /proc/sys/vm/dirty_ratio
echo "5" > /proc/sys/vm/dirty_background_ratio

# Apply I/O scheduler optimizations
for block in /sys/block/*/queue/scheduler; do
  if [ -f "$block" ]; then
    echo "cfq" > "$block" 2>/dev/null
  fi
done

# Apply kernel parameters for rendering
echo "0" > /proc/sys/kernel/randomize_va_space 2>/dev/null

# Log the start of optimization process
/system/bin/log -t "FasterRendering" "Early boot optimizations applied" 