#!/system/bin/sh
# Faster Rendering Module
# Author: willygailo01@gmail.com

MODDIR=${0%/*}

# Make module executable
set_perm_recursive $MODDIR 0 0 0755 0644
set_perm_recursive $MODDIR/system 0 0 0755 0644
set_perm $MODDIR/system/bin/render_optimizer 0 0 0755

# Print module info during installation
ui_print "******************************"
ui_print "     Faster Rendering v1.0    "
ui_print "******************************"
ui_print " Author: willygailo01@gmail.com "
ui_print " "
ui_print " Optimizing device rendering... "
ui_print " Improving app loading speed... "
ui_print " Enhancing game graphics... "
ui_print " Reducing system lag... "
ui_print " "
ui_print " This module supports all Android 10+ devices "
ui_print "******************************" 