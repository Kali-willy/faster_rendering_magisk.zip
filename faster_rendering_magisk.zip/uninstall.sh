#!/system/bin/sh
# Uninstall script for Faster Rendering Module
# Author: willygailo01@gmail.com

# Restore default settings
# Reset GPU rendering parameters
resetprop --delete debug.egl.swapinterval
resetprop --delete debug.hwui.renderer
resetprop --delete debug.composition.type
resetprop --delete ro.hwui.texture_cache_size
resetprop --delete ro.hwui.layer_cache_size
resetprop --delete ro.hwui.path_cache_size
resetprop --delete ro.hwui.gradient_cache_size
resetprop --delete ro.hwui.drop_shadow_cache_size
resetprop --delete ro.hwui.r_buffer_cache_size
resetprop --delete ro.hwui.text_small_cache_width
resetprop --delete ro.hwui.text_small_cache_height
resetprop --delete ro.hwui.text_large_cache_width
resetprop --delete ro.hwui.text_large_cache_height

# Reset game optimizations
resetprop --delete persist.vendor.bluetooth.a2dp.hal.implementation
resetprop --delete persist.sys.dalvik.vm.lib.2
resetprop --delete persist.sys.ssr.restart_level
resetprop --delete debug.sf.hw

# Reset Android 10+ specific tweaks
resetprop --delete debug.sf.latch_unsignaled
resetprop --delete ro.surface_flinger.has_wide_color_display
resetprop --delete ro.surface_flinger.has_HDR_display
resetprop --delete ro.surface_flinger.use_color_management
resetprop --delete ro.surface_flinger.max_frame_buffer_acquired_buffers

# Log the uninstallation
/system/bin/log -t "FasterRendering" "Module uninstalled, settings restored to default" 