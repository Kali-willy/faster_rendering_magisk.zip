#!/bin/sh
# Script to package the Faster Rendering Module
# Author: willygailo01@gmail.com

# Set permissions
chmod -R 755 META-INF
chmod 644 module.prop
chmod 755 install.sh
chmod 755 uninstall.sh
chmod 755 service.sh
chmod 755 post-fs-data.sh
chmod 755 system/bin/render_optimizer
chmod 644 system/etc/render_config.conf
chmod 644 README.md

# Create the zip file
zip -r faster_rendering.zip META-INF module.prop install.sh uninstall.sh service.sh post-fs-data.sh system README.md

echo "Package created: faster_rendering.zip" 