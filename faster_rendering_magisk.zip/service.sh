#!/system/bin/sh
# Faster Rendering Module - Service Script
# Author: willygailo01@gmail.com

MODDIR=${0%/*}

# Wait until boot completed
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

# Apply rendering optimizations
# Set GPU rendering parameters
setprop debug.egl.swapinterval 0
setprop debug.hwui.renderer skiagl
setprop debug.composition.type gpu
setprop ro.hwui.texture_cache_size 72
setprop ro.hwui.layer_cache_size 48
setprop ro.hwui.path_cache_size 32
setprop ro.hwui.gradient_cache_size 1
setprop ro.hwui.drop_shadow_cache_size 6
setprop ro.hwui.r_buffer_cache_size 8
setprop ro.hwui.text_small_cache_width 1024
setprop ro.hwui.text_small_cache_height 1024
setprop ro.hwui.text_large_cache_width 2048
setprop ro.hwui.text_large_cache_height 1024

# Improve app loading
setprop dalvik.vm.dex2oat-filter speed
setprop dalvik.vm.image-dex2oat-filter speed

# Game optimizations
setprop persist.vendor.bluetooth.a2dp.hal.implementation true
setprop persist.sys.dalvik.vm.lib.2 libart.so
setprop persist.sys.ssr.restart_level ALL_ENABLE
setprop debug.sf.hw 1

# Check Android version and apply specific optimizations
if [ "$(getprop ro.build.version.sdk)" -ge 29 ]; then
  # Android 10+ specific tweaks
  setprop debug.sf.latch_unsignaled 1
  setprop ro.surface_flinger.has_wide_color_display 1
  setprop ro.surface_flinger.has_HDR_display 1
  setprop ro.surface_flinger.use_color_management 1
  
  # Enable Triple Buffering for better performance
  setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3
fi

# Process optimization
for pid in $(ps -A | grep -v PID | awk '{print $1}'); do
  # Skip system critical processes
  if [ -f "/proc/$pid/oom_score_adj" ]; then
    # Set OOM priority for background apps
    echo 0 > /proc/$pid/oom_score_adj 2>/dev/null
  fi
done

# Apply CPU performance settings
# Find available CPU governors
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  [ -f "$cpu" ] && echo "performance" > "$cpu" 2>/dev/null
done

# Apply GPU performance settings
for gpu in /sys/class/kgsl/kgsl-3d0/devfreq/governor; do
  [ -f "$gpu" ] && echo "performance" > "$gpu" 2>/dev/null
done

# Log the completion of optimization
/system/bin/log -t "FasterRendering" "Rendering optimizations applied successfully" 